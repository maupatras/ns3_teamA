This is ns-3 installation guide for the versions 3.15 up to 3.22 (latest ns-3.22 version release, February 2015).

-------------------------------------------------
|    Installation Steps (Ubuntu/Debian OS)      |
-------------------------------------------------

=== Main way ===
1. Download installation file (installation.zip) and extract it
2. Execute install_guide file (double click) and then follow the instructions

=== Alternative way ===
1. Download installation file (installation.zip) and extract it
2. Copy and Paste the configure.sh file to the home folder
3. Open a terminal (CTRL-ALT-T)
4. Change directory to home folder typing 'cd' command
5. Run the bash script typing ./configure.sh and follow the instructions
