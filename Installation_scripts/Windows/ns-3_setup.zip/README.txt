This is ns-3 installation guide for the versions 3.15 up to 3.22 (latest ns-3.22 version release, February 2015).

-------------------------------------------------
|    Installation Steps (Windows OS)      |
-------------------------------------------------

1. Open a Powershell v3 or greater console
2. Navigate to the script's folder (using cd), or copy the script to Powershell's current folder
3. Allow Powershell script execution by running "Set-ExecutionPolicy Unrestricted -Scope Process"
4. Execute the script by running ".\setup.ps1 -parameter1 value1 -parameter2 value2"
   The number of parameters can be any from none to all of the parameters listed.
5. Follow any instructions that show up